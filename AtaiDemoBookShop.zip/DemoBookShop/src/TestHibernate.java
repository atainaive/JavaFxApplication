import dsmodules.Individual;
import dsmodules.LegalPerson;
import dsmodules.User;
import dsmodules.UserType;
import hibernateControllers.UserController;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

    public class TestHibernate {
        public static void main(String[] args) {
            EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
            UserController userController = new UserController(entityManagerFactory);

            userController.createUser(new LegalPerson("a","a","a","a",1, UserType.ADMIN,"a","a"));

            User user = userController.getUserByCredentials("a","a");


        }
    }
