package WebConntrollers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dsmodules.Individual;
import dsmodules.LegalPerson;
import dsmodules.User;
import dsmodules.UserType;
import hibernateControllers.UserController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import utilities.IndividualGsonSerializer;
import utilities.LocalDateGsonSerializer;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.time.LocalDate;
import java.util.Properties;

@Controller
public class UserWeb {

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserController userController = new UserController(entityManagerFactory);

    @RequestMapping(value = "/users/test", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public String Test() {
        return "yay";
    }

    @RequestMapping(value = "/users/validateUser", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public String validateWebUser(@RequestBody String request) {
        Gson parser = new Gson();
        Properties data = parser.fromJson(request, Properties.class);
        User user = userController.getUserByCredentials(data.getProperty("login"), data.getProperty("password"));

        GsonBuilder builder = new GsonBuilder();

        builder.registerTypeAdapter(LocalDate.class, new LocalDateGsonSerializer())
                .registerTypeAdapter(Individual.class, new IndividualGsonSerializer());
        if (user.getClass() == Individual.class) {
            Individual individual = (Individual) user;
            return (builder.create().toJson(individual));
        } else {
            LegalPerson legalPerson = (LegalPerson) user;
            return (builder.create().toJson(legalPerson, LegalPerson.class));
        }
    }

    @RequestMapping(value = "/users/addUser", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public String addWebUser(@RequestBody String request) {
        Gson parser = new Gson();
        Properties data = parser.fromJson(request, Properties.class);
        Individual individual = null;
        LegalPerson legalPerson = null;
        if (data.getProperty("userType").equals("L")) {
            userController.createUser(new LegalPerson(
                    data.getProperty("login"),
                    data.getProperty("password"),
                    data.getProperty("email"),
                    data.getProperty("address"),
                    Integer.parseInt(data.getProperty("zip")),
                    UserType.valueOf(data.getProperty("type")),
                    data.getProperty("compTitle"),
                    data.getProperty("ceo")));
            legalPerson = (LegalPerson) userController.getUserByCredentials(data.getProperty("login"), data.getProperty("password"));
        } else if (data.getProperty("userType").equals("I")) {
            individual = (Individual) userController.getUserByCredentials(data.getProperty("login"), data.getProperty("password"));
        }
        GsonBuilder builder = new GsonBuilder();
        builder.registerTypeAdapter(LocalDate.class, new LocalDateGsonSerializer());
        if (individual != null) {

            return (builder.create().toJson(individual, Individual.class));
        } else if (legalPerson != null) {
            return (builder.create().toJson(legalPerson, LegalPerson.class));
        }
        return "Fail";
    }

    @RequestMapping(value = "/users/deleteUser/{id}", method = RequestMethod.DELETE)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public String deleteUserWeb(@PathVariable(name = "id") int id) {
        userController.deleteUser(id);

        User user = userController.getUserById(id);
        if (user == null) return "Success";
        else return "Not deleted";
    }

    @RequestMapping(value = "/users/updateUser", method = RequestMethod.PUT)
    @ResponseStatus(value = HttpStatus.OK)
    @ResponseBody
    public String updateWebUser(@RequestBody String request) {
        Gson parser = new Gson();
        Properties data = parser.fromJson(request, Properties.class);
        Individual individual = null;
        LegalPerson legalPerson = null;
        if (data.getProperty("userType").equals("I")) {
            individual = (Individual) userController.getUserById(Integer.parseInt(data.getProperty("id")));

            individual.setName(data.getProperty("name"));
            individual.setEmail(data.getProperty("email"));
            userController.editUser(individual);
            return "Updated";
        } else if (data.getProperty("userType").equals("L")) {
            //finish specific
            return "Updated";
        } else {
            return "No such user type, unable to update";
        }
    }
}
