package WebConntrollers;

import org.springframework.stereotype.Controller;

@Controller
public class CartWeb {
}
