package utilities;

import javafx.scene.control.Alert;

public class AlertMessage {
    public static void throwMessage(String headerText, String contentText) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Book shop info:");
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
}
