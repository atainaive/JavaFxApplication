package hibernateControllers;

import dsmodules.Book;
import dsmodules.Genre;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookController {
    private EntityManagerFactory emf = null;

    public BookController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void createBook(Book book) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(book);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void editBook(Book book) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(book);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) em.close();
        }
    }

    public void deleteBook(int id) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Book book = null;
            try {
                book = em.getReference(Book.class, id);
                book.getBookId();
            } catch (Exception e) {
                System.out.println("No such book by given Id");
            }
            em.remove(book);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public Book getBookById(int id){
        EntityManager em = null;
        Book book = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            book = em.find(Book.class, id);
            em.getTransaction().commit();
        } catch (Exception e) {
            System.out.println("No such book by given Id");
        }
        return book;
    }

    public List<Book> getAllAvailableBooks(boolean isAvailable) {
        EntityManager em = emf.createEntityManager();
        try {
            CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
            CriteriaQuery<Book> query = criteriaBuilder.createQuery(Book.class);
            Root<Book> root = query.from(Book.class);
            if (isAvailable)
                query.select(root).where(criteriaBuilder.equal(root.get("available"), true));
            Query q = em.createQuery(query);
            return q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return new ArrayList<>();
    }

    public List<Book> getFilteredBooks(String title, String authors, String description, LocalDate publishDateStart, LocalDate publishDateEnd, int pages, int edition, double price, Genre genre) {
        EntityManager em = getEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Book> query = cb.createQuery(Book.class);
            Root<Book> root = query.from(Book.class);
            query.select(root).where(cb.and(cb.like(root.get("bookTitle"), "%" + title + "%")), cb.like(root.get("authors"), "%" + authors + "%"), cb.like(root.get("description"), "%" + description + "%"), cb.between(root.get("datePublished"), publishDateStart, publishDateEnd), cb.like(root.get("pages"), "%" + pages + "%"), cb.like(root.get("edition"), "%" + edition + "%"), cb.like(root.get("price"), "%" + price + "%"), cb.like(root.get("genre"), "%" + genre + "%"));
            Query q = em.createQuery(query);
            return q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return null;
    }

//    public List<Book> getFilteredBooks(String title, String authors, String description, LocalDate publishDateStart, LocalDate publishDateEnd, int pages, int edition, double price, Genre genre){
//        EntityManager em = getEntityManager();
//        try {
//            CriteriaBuilder cb = em.getCriteriaBuilder();
//            CriteriaQuery<Book> query = cb.createQuery(Book.class);
//            Root<Book> root = query.from(Book.class);
//
//            List<Predicate> predicates = new ArrayList<Predicate>();
//
//          if (!price_from.isBlank())
//               predicates.add(cb.greaterThanOrEqualTo(root.get("price"), Integer.parseInt(price_from)));
//           if (!price_to.isBlank())
//                predicates.add(cb.lessThanOrEqualTo(root.get("price"), Integer.parseInt(price_to)));
//           if(title != "All")
//               predicates.add(cb.equal(root.get("lang"), eBookLang.valueOf(title)));
//            if(genre != "All")
//               predicates.add(cb.equal(root.get("genre"), eBookGenre.valueOf(genre)));
//
//            query.select(root).where(predicates.toArray(new Predicate[]{}));
//            Query q = em.createQuery(query);
//            return q.getResultList();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (em != null) {
//                em.close();
//            }
//        }
//        return null;
//    }
}
