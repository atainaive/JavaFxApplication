package dsmodules;

public enum Genre {
    NOVEL, ROMANCE, DRAMA, DETECTIVE, SCI_FI, FANTASY, FOR_KIDS;
}
