package dsmodules;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.OrderBy;
import java.time.LocalDate;
import java.util.List;

@Entity
@Getter
@Setter
public class Individual extends User {
    private String name;
    private String surname;
    private int phoneNum;
    private LocalDate birthDate;
    @ManyToMany(mappedBy = "supervisingEmployees", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @OrderBy("id ASC")
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Cart> myManagedOrders;

    public Individual(int userId, String login, String password, String email, String address, LocalDate dateCreated, LocalDate dateModified, int zipCode, UserType userType, String name, String surname, int phoneNum, LocalDate birthDate) {
        super(userId, login, password, email, address, dateCreated, dateModified, zipCode, userType);
        this.name = name;
        this.surname = surname;
        this.phoneNum = phoneNum;
        this.birthDate = birthDate;
    }

    public Individual(String login, String password, String email, String address, int zipCode, UserType userType, String name, String surname, int phoneNum, LocalDate birthDate) {
        super(login, password, email, address, zipCode, userType);
        this.name = name;
        this.surname = surname;
        this.phoneNum = phoneNum;
        this.birthDate = birthDate;
    }

    public Individual() {

    }
}
