package dsmodules;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookId;
    private String title;
    private String author;
    private String description;
    private LocalDate datePublished;
    private int pages;
    private int edition;
    private double price;
    private Genre genre;
    @Transient
    private boolean available;
    @ManyToMany(mappedBy = "items", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @OrderBy("id ASC")
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Cart> inCart;

    @OneToMany(mappedBy = "bookComment", cascade = {CascadeType.PERSIST, CascadeType.MERGE}, orphanRemoval = true)
    @OrderBy("id ASC")
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Comment> comments;

    public Book(String title, String author, String description, LocalDate datePublished, int pages, int edition, double price, Genre genre, boolean available) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.datePublished = datePublished;
        this.pages = pages;
        this.edition = edition;
        this.price = price;
        this.genre = genre;
        this.available = available;
    }

}
