package dsmodules;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Entity
@Getter
@Setter
public abstract class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
    @Column(unique = true)
    private String login;
    private String password;
    private String email;
    private String address;
    private LocalDate dateCreated;
    private LocalDate dateModified;
    private int zipCode;
    private int cartId;
    @OneToMany(mappedBy = "buyer", cascade = CascadeType.ALL)
    @OrderBy("id ASC")
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Cart> myCart;
    @Enumerated
    private UserType userType;

    public User() {
    }

    public User(String login, String password, UserType userType) {
        this.login = login;
        this.password = password;
        this.userType = userType;
    }

    public User(String login, String password, String email, String address, int zipCode, UserType userType) {
        this.login = login;
        this.password = password;
        this.email = email;
        this.address = address;
        this.dateCreated = LocalDate.now();
        this.dateModified = LocalDate.now();
        this.zipCode = zipCode;
        this.userType = userType;
    }

    public User(int userId, String login, String password, String email, String address, LocalDate dateCreated, LocalDate dateModified, int zipCode, UserType userType) {
        this.userId = userId;
        this.login = login;
        this.password = password;
        this.email = email;
        this.address = address;
        this.dateCreated = dateCreated;
        this.dateModified = dateModified;
        this.zipCode = zipCode;
        this.userType = userType;
    }
}
