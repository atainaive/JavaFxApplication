package dsmodules;

import java.io.Serializable;
import java.util.ArrayList;

public class BookShop implements Serializable {
     ArrayList<User> allUser;
     ArrayList<Book> allBooks;
     ArrayList<Cart> allOrders;

    public BookShop() {
        this.allUser = new ArrayList<>();
        this.allBooks = new ArrayList<>();
        this.allOrders = new ArrayList<>();
    }
}
