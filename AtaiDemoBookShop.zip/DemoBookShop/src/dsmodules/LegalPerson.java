package dsmodules;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import java.time.LocalDate;

@Entity
@Data
public class LegalPerson extends User {
    private String companyTitle;
    private String ceo;

    public LegalPerson(String login, String password, String email, String address, int zipCode, UserType userType, String companyTitle, String ceo) {
        super(login, password, email, address, zipCode, userType);
        this.companyTitle = companyTitle;
        this.ceo = ceo;
    }

    public LegalPerson(int userId, String login, String password, String email, String address, LocalDate dateCreated, LocalDate dateModified, int zipCode, UserType userType, String companyTitle, String ceo) {
        super(userId, login, password, email, address, dateCreated, dateModified, zipCode, userType);
        this.companyTitle = companyTitle;
        this.ceo = ceo;
    }

    public LegalPerson() {}
}
