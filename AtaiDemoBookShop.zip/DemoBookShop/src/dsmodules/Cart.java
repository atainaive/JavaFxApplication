package dsmodules;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private LocalDate orderDate;
    @ManyToOne
    private User buyer;
    @ManyToMany
    private List<Book> items;
    @ManyToMany
    private List<Individual> supervisingEmployees;

    public Cart(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public Cart(int id, LocalDate orderDate) {
        this.id = id;
        this.orderDate = orderDate;
    }
}
