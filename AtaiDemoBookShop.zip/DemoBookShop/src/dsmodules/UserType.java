package dsmodules;

public enum UserType {
    ADMIN, EMPLOYEE, CUSTOMER;
}
