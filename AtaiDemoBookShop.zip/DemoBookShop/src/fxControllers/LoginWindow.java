package fxControllers;

import dsmodules.User;
import hibernateControllers.UserController;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;

import static utilities.AlertMessage.throwMessage;

public class LoginWindow extends Application {

    @FXML
    public TextField logF;
    @FXML
    public PasswordField passF;
    @FXML
    public Button logInButton;

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserController userController = new UserController(entityManagerFactory);


    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("/view/Start.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("LogIn");
        stage.setScene(scene);
        stage.show();
    }

    public void validateAndLogIn() throws IOException {
        User user = userController.getUserByCredentials(logF.getText(), passF.getText());
        if (user != null) {
            FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("/view/MainWindow.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            MainWindow mainWindow = fxmlLoader.getController();
            mainWindow.setUserId(user.getUserId());
            Stage stage = (Stage) logF.getScene().getWindow();
            stage.setTitle("MainWindow");
            stage.setScene(scene);
            stage.show();
        } else {
            throwMessage("Error!!!", "No Such User!!!");
        }
    }

    public void loadSignUp() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("/view/SignUpWindow.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) logF.getScene().getWindow();
        stage.setTitle("SignUp");
        stage.setScene(scene);
        stage.show();
    }

}
