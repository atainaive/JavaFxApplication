package fxControllers;

import dsmodules.Book;
import dsmodules.Comment;
import dsmodules.User;
import dsmodules.UserType;
import hibernateControllers.BookController;
import hibernateControllers.UserController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;

public class CommentWindow {
    @FXML
    public TextArea commentArea;
    @FXML
    public Button saveComment;
    @FXML
    public Button cancelComment;
    public Button returnToMain;
    private int userId;
    private int bookId;
    private int commentId;


    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    BookController bookController = new BookController(entityManagerFactory);
    UserController userController = new UserController(entityManagerFactory);

    public CommentWindow(int userId) {
        this.userId = userId;
    }


    public void cancelComment () throws IOException {
            FXMLLoader fxmlLoader = new FXMLLoader(MainWindow.class.getResource("/view/MainWindow.fxml"));
            MainWindow mainWindow = fxmlLoader.getController();
            mainWindow.setUserId(userId);
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) commentArea.getScene().getWindow();
            stage.setTitle("MainWindow");
            stage.setScene(scene);
            stage.show();
        }

        public void setBookId ( int bookId, int commentId){
            this.bookId = bookId;
            this.commentId = commentId;
        }

    public void saveComment(ActionEvent actionEvent) {
        if (bookId != 0) {
            Book book = bookController.getBookById(bookId);
            Comment comment = new Comment(commentArea.getText(), null, book);
            book.getComments().add(comment);
            bookController.editBook(book);
        }
    }

    public void returnToMain() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(CommentWindow.class.getResource("/view/MainWindow.fxml"));
       // MainWindow mainWindow = fxmlLoader.getController();
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) commentArea.getScene().getWindow();
        stage.setTitle("MainWindow");
        stage.setScene(scene);
        stage.show();
    }
}
