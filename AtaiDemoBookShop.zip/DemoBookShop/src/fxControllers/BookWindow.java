package fxControllers;

import dsmodules.Book;
import dsmodules.Genre;
import hibernateControllers.BookController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class BookWindow implements Initializable {
    @FXML
    public TextField title;
    @FXML
    public TextField author;
    @FXML
    public TextField pages;
    @FXML
    public TextField edition;
    @FXML
    public DatePicker published;
    @FXML
    public DatePicker modified;
    @FXML
    public TextField price;
    @FXML
    public ComboBox genre;
    @FXML
    public ListView listBooks;
    @FXML
    public TextArea description;
    @FXML
    public Button addBook;
    @FXML
    public Button removeBook;
    @FXML
    public Button changeBook;
    @FXML
    public CheckBox available;
    private int bookId;

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    BookController bookController = new BookController(entityManagerFactory);

    public void setBookId(int Id)
    {
        this.bookId = Id;
    }

    public void addBook(ActionEvent actionEvent) {
        Book book = new Book(title.getText(), author.getText(), description.getText(), published.getValue(), Integer.parseInt(pages.getText()), Integer.parseInt(edition.getText()), Double.parseDouble(price.getText()), Genre.valueOf(genre.getSelectionModel().getSelectedItem().toString()), available.isSelected());
        bookController.createBook(book);
        refreshListBook();
    }

    public void removeBook(ActionEvent actionEvent) {
        String bookId = listBooks.getSelectionModel().getSelectedItem().toString().split(":")[0];
        bookController.deleteBook(Integer.parseInt(bookId));

    }
    public void editBook(ActionEvent actionEvent) {
        addBook.setDisable(true);
        changeBook.setVisible(true);

        String bookId = listBooks.getSelectionModel().getSelectedItem().toString().split(":")[0];

        Book book = bookController.getBookById(Integer.parseInt(bookId));
        title.setText(book.getTitle());
        description.setText(book.getDescription());
        published.setValue(book.getDatePublished());
        pages.setText(String.valueOf(book.getPages()));
        edition.setText(String.valueOf(book.getEdition()));
        price.setText(String.valueOf(book.getPrice()));
        genre.setValue(book.getGenre());
        available.setSelected(book.isAvailable());

    }
    public void changeBook(ActionEvent actionEvent) {
        String bookId = listBooks.getSelectionModel().getSelectedItem().toString().split(":")[0];
        Book updatedBook = bookController.getBookById(Integer.parseInt(bookId));

        updatedBook.setTitle(title.getText());
        updatedBook.setAuthor(author.getText());
        updatedBook.setDescription(description.getText());
        updatedBook.setDatePublished(published.getValue());
        updatedBook.setPages(Integer.parseInt(pages.getText()));
        updatedBook.setEdition(Integer.parseInt(edition.getText()));
        updatedBook.setPrice(Double.parseDouble(price.getText()));
        updatedBook.setGenre(Genre.valueOf(genre.getSelectionModel().getSelectedItem().toString()));
        updatedBook.setAvailable(available.isSelected());
        bookController.editBook(updatedBook);
        refreshListBook();
    }

    public void refreshListBook() {
        List<Book> allAvailableBooks = bookController.getAllAvailableBooks(false);
        listBooks.getItems().clear();
        allAvailableBooks.forEach(book -> listBooks.getItems().add(book.getBookId() + ":" + book.getTitle()));

        title.clear();
        author.clear();
        edition.clear();
        published.getEditor().clear();
        modified.getEditor().clear();
        price.clear();
        pages.clear();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        genre.getItems().addAll(Genre.values());
        refreshListBook();
    }

    public void goBack(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(BookWindow.class.getResource("/view/MainWindow.fxml"));
        MainWindow mainWindow = fxmlLoader.getController();
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) title.getScene().getWindow();
        stage.setTitle("MainWindow");
        stage.setScene(scene);
        stage.show();
    }


}
