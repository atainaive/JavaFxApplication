package fxControllers;

import dsmodules.*;
import hibernateControllers.BookController;
import hibernateControllers.CartController;
import hibernateControllers.UserController;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

@Getter
@Setter
public class MainWindow implements Initializable {
    @FXML
    public ListView bookList;
    @FXML
    public TreeView commentsBook;
    @FXML
    public ListView listBooksHome;
    @FXML
    public ComboBox searchGenre;
    @FXML
    public TextField searchTitle;
    @FXML
    public TextField searchAuthor;
    @FXML
    public TextField searchPage;
    @FXML
    public DatePicker searchDate;
    @FXML
    public DatePicker searchDateEnd;
    @FXML
    public Button addToCart;
    @FXML
    public TextArea searchDescription;
    @FXML
    public TextField searchPrice;
    @FXML
    public TextField searchEdition;
    @FXML
    public TextArea cartInfo;
    @FXML
    public ListView cartList;
    @FXML
    public Button cartApprove;
    @FXML
    public Button cartDiscard;
    @FXML
    public Button cartChange;
    @FXML
    public AnchorPane addUser;
    @FXML
    public Button adminAddUsers;
    @FXML
    public ListView adminUserList;
    @FXML
    public CheckBox available;
    @FXML
    public Button manageUpdateBook;
    @FXML
    public Tab manageTab;
    @FXML
    public Tab adminTab;
    @FXML
    public TreeView bookCommentTree;
    @FXML
    public Button writeComment;
    @FXML
    public ListView cartEmp;
    @FXML
    public Button cartDiscard1;
    @FXML
    public ListView approvedCarts;
    @FXML
    public Tab employeeTab;
    @FXML
    public ListView orderList;
    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserController userController = new UserController(entityManagerFactory);
    BookController bookController = new BookController(entityManagerFactory);
    CartController cartController = new CartController(entityManagerFactory);
    private int userId;
    private List<Book> addToCartList;
    private int bookId;

    public void setUserId(int userId) {
        this.userId = userId;
        updateAccess();
    }


    // general
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        searchGenre.getItems().addAll(Genre.values());
        refreshBooks();
        addToCartList = new ArrayList<>();
        //refreshUsers();
    }

    private void updateAccess() {
        User user = userController.getUserById(userId);
        if (user.getUserType() == UserType.CUSTOMER) {
            adminTab.setDisable(true);
            employeeTab.setDisable(true);

        } else if (user.getUserType() == UserType.EMPLOYEE) {
            adminTab.setDisable(true);
            employeeTab.setDisable(false);
        } else if (user.getUserType() == UserType.ADMIN) {
            adminTab.setDisable(false);
            employeeTab.setDisable(false);
        }
    }

    public void refreshBooks() {
        listBooksHome.getItems().clear();
        List<Book> allBooks = bookController.getAllAvailableBooks(false);
        allBooks.forEach(book -> listBooksHome.getItems().add(book.getBookId() + ":" + book.getTitle()));
    }

    public void addTreeItem(Comment comment, TreeItem parent) {
        TreeItem<Comment> treeItem = new TreeItem<>(comment);
        parent.getChildren().add(treeItem);
        comment.getReplies().forEach(sub -> addTreeItem(sub, treeItem));
    }

    public void loadComments() {
        String bookId = listBooksHome.getSelectionModel().getSelectedItem().toString().split(":")[0];
        Book book = bookController.getBookById(Integer.parseInt(bookId));
        bookCommentTree.setRoot(new TreeItem<String>("Comments:"));
        bookCommentTree.setShowRoot(false);
        bookCommentTree.getRoot().setExpanded(true);
        book.getComments().forEach(task -> addTreeItem(task, bookCommentTree.getRoot()));
    }
    // end of general


    // shop tab
    public void searchBook() {
        List<Book> filteredBooks = bookController.getFilteredBooks(searchTitle.getText(), searchAuthor.getText(), searchDescription.getText(), searchDate.getValue(), searchDateEnd.getValue(), Integer.parseInt(searchPage.getText()), Integer.parseInt(searchEdition.getText()), Double.parseDouble(searchPrice.getText()), Genre.valueOf(searchGenre.getSelectionModel().getSelectedItem().toString()));
        listBooksHome.getItems().clear();
        filteredBooks.forEach(book -> listBooksHome.getItems().add(book.getBookId() + ":" + book.getTitle()));
    }

    public void writeCommentPage(ActionEvent actionEvent) throws IOException {

    }

    public void addToCart(ActionEvent actionEvent) {
        String stringBookId = listBooksHome.getSelectionModel().getSelectedItem().toString().split(":")[0];
        bookId = Integer.parseInt(stringBookId);
        Book book = bookController.getBookById(bookId);
        addToCartList.add(book);
    }
    // end of shop tab


    // cart tab


    public void cartTab(Event event) {
        User user = userController.getUserById(userId);
        cartList.getItems().clear();
        if (addToCartList != null) {
            cartList.getItems().clear();
            addToCartList.forEach(book -> cartList.getItems().add(book.getBookId() + ":" + book.getTitle()));
        }

        if (user.getCartId() == -1) {
            user.setCartId(0);
        }

        if (orderList != null) {
            Cart order = cartController.getCartById(user.getCartId());
            orderList.getItems().clear();
            orderList.getItems().add(order.getId() + " " + order.getBuyer());
        }


    }

    public void orderCart(ActionEvent actionEvent) {
        User user = userController.getUserById(userId);
        if (addToCartList.size() != 0) {
            Cart cart = new Cart(LocalDate.now());
            cart.getSupervisingEmployees().add((Individual) user);
            user.getMyCart().add(cart);
            userController.editUser(user);
        }
    }

    public void removeCart(ActionEvent actionEvent) {
    }

    public void orderDelete(ActionEvent actionEvent) {
    }


    // end of cart tab


    // employee tab
    public void cartApprove(ActionEvent actionEvent) {
    }


    public void employeeTabSelected(Event event) {
    }

    public void cartDiscard(ActionEvent actionEvent) {
    }

    // end of employee tab


    // admin tab
    public void addUser() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainWindow.class.getResource("/view/UsersWindow.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) adminAddUsers.getScene().getWindow();
        stage.setTitle("AdminAddUser");
        stage.setScene(scene);
        stage.show();
    }


    public void openManageBookTab() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainWindow.class.getResource("/view/BookWindow.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) adminUserList.getScene().getWindow();
        stage.setTitle("Books Manager");
        stage.setScene(scene);
        stage.show();
    }

    public void removeUser() {
        String userId = adminUserList.getSelectionModel().getSelectedItem().toString().split(":")[0];
        userController.deleteUser(Integer.parseInt(userId));
    }

    public void writeComment(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainWindow.class.getResource("/view/CommentWindow.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) writeComment.getScene().getWindow();
        stage.setTitle("Comments");
        stage.setScene(scene);
        stage.show();
    }


//    public void refreshUsers() {
//        List<User> allUsers = userController.getAllUsers();
//        adminUserList.getItems().clear();
//        allUsers.forEach(user -> adminUserList.getItems().add(user.getEmail() + ":" + user.getUserType()));
//    }
    // end of admin tab

}
