package fxControllers;

import dsmodules.Individual;
import dsmodules.LegalPerson;
import dsmodules.UserType;
import hibernateControllers.UserController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class UsersWindow implements Initializable {
    @FXML
    public TextField loginAdmin;
    @FXML
    public TextField emailAdmin;
    @FXML
    public TextField zipAdmin;
    @FXML
    public TextField surnameAdmin;
    @FXML
    public TextField passAdmin;
    @FXML
    public TextField addressAdmin;
    @FXML
    public TextField nameAdmin;
    @FXML
    public TextField numberAdmin;
    @FXML
    public ComboBox roleAdmin;
    @FXML
    public RadioButton invAdmin;
    @FXML
    public RadioButton legalAdmin;
    @FXML
    public Button createAdmin;
    @FXML
    public Button cancelAdmin;
    @FXML
    public DatePicker birthAdmin;
    @FXML
    public TextField ceoAdmin;
    @FXML
    public TextField companyAdmin;
    @FXML

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserController userController = new UserController(entityManagerFactory);

    public void disableFieldsAdmin() {
            if(invAdmin.isSelected()){
                nameAdmin.setDisable(false);
                surnameAdmin.setDisable(false);
                numberAdmin.setDisable(false);
                birthAdmin.setDisable(false);
                ceoAdmin.setDisable(true);
                companyAdmin.setDisable(true);
            } else if(legalAdmin.isSelected()){
                nameAdmin.setDisable(true);
                surnameAdmin.setDisable(true);
                numberAdmin.setDisable(true);
                birthAdmin.setDisable(true);
                ceoAdmin.setDisable(false);
                companyAdmin.setDisable(false);
            }
    }

    public void createUserAdmin() {
        if (invAdmin.isSelected()) {
            userController.createUser(new Individual(loginAdmin.getText(), passAdmin.getText(), emailAdmin.getText(), addressAdmin.getText(), Integer.parseInt(zipAdmin.getText()), UserType.valueOf(roleAdmin.getSelectionModel().getSelectedItem().toString()), nameAdmin.getText(), surnameAdmin.getText(), Integer.parseInt(numberAdmin.getText()), birthAdmin.getValue()));
        } else if (legalAdmin.isSelected()) {
            userController.createUser(new LegalPerson(loginAdmin.getText(), passAdmin.getText(), emailAdmin.getText(), addressAdmin.getText(), Integer.parseInt(zipAdmin.getText()), UserType.valueOf(roleAdmin.getSelectionModel().getSelectedItem().toString()), companyAdmin.getText(), ceoAdmin.getText()));
        }
    }

    public void cancelAdmin(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("/view/MainWindow.fxml"));
        MainWindow mainWindow = fxmlLoader.getController();
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) loginAdmin.getScene().getWindow();
        stage.setTitle("MainWindow");
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //disableFieldsAdmin();

        roleAdmin.getItems().clear();
        roleAdmin.getItems().addAll(UserType.values());
    }

}
