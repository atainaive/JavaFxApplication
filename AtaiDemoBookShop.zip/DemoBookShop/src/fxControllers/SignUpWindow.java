package fxControllers;

import dsmodules.Individual;
import dsmodules.LegalPerson;
import dsmodules.User;
import dsmodules.UserType;
import hibernateControllers.UserController;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static utilities.AlertMessage.throwMessage;

public class SignUpWindow implements Initializable {
    @FXML
    public TextField signUpName;
    @FXML
    public TextField signUpSurname;
    @FXML
    public TextField signUpEmail;
    @FXML
    public TextField signUpLogin;
    @FXML
    public TextField signUpPassword;
    @FXML
    public TextField signUpNum;
    @FXML
    public RadioButton signUpIndividual;
    @FXML
    public RadioButton signUpLegal;
    @FXML
    public ComboBox signUpRole;
    @FXML
    public TextField signUpAddress;
    @FXML
    public TextField signUpZip;
    @FXML
    public TextField signUpCompTitle;
    @FXML
    public TextField signUpCeo;
    @FXML
    public DatePicker signUpBirthdate;

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserController userController = new UserController(entityManagerFactory);

    public void ValidateSignUp() throws IOException {
        if (signUpIndividual.isSelected()) {
            userController.createUser(new Individual(signUpLogin.getText(), signUpPassword.getText(), signUpEmail.getText(), signUpAddress.getText(), Integer.parseInt(signUpZip.getText()), UserType.valueOf(signUpRole.getSelectionModel().getSelectedItem().toString()), signUpName.getText(), signUpSurname.getText(), Integer.parseInt(signUpNum.getText()), signUpBirthdate.getValue()));
            ValidateLogInWindow();
        } else if (signUpLegal.isSelected()) {
            userController.createUser(new LegalPerson(signUpLogin.getText(), signUpPassword.getText(), signUpEmail.getText(), signUpAddress.getText(), Integer.parseInt(signUpZip.getText()), UserType.valueOf(signUpRole.getSelectionModel().getSelectedItem().toString()), signUpCompTitle.getText(), signUpCeo.getText()));
            ValidateLogInWindow();
        } else {
            throwMessage("Error", "User couldn't get created!!!");
        }
    }

    public void ValidateLogInWindow() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginWindow.class.getResource("/view/Start.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        Stage stage = (Stage) signUpLogin.getScene().getWindow();
        stage.setTitle("LogIn");
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        disableFields();
        empOnlyFields();

        signUpRole.getItems().clear();
        signUpRole.getItems().addAll(UserType.values());
    }

    public void disableFields() {
        if (signUpIndividual.isSelected()) {
            signUpCompTitle.setVisible(false);
            signUpCeo.setVisible(false);
            signUpName.setVisible(true);
            signUpSurname.setVisible(true);
            signUpBirthdate.setVisible(true);
            signUpNum.setVisible(true);
        } else if(signUpLegal.isSelected()) {
            signUpCompTitle.setVisible(true);
            signUpCeo.setVisible(true);
            signUpName.setVisible(false);
            signUpSurname.setVisible(false);
            signUpBirthdate.setVisible(false);
            signUpNum.setVisible(false);
        }
    }

    public void empOnlyFields(){
        if(UserType.EMPLOYEE == signUpRole.getValue()){
            signUpCompTitle.setVisible(false);
            signUpCeo.setVisible(false);
            signUpLegal.setVisible(false);
            signUpName.setVisible(true);
            signUpSurname.setVisible(true);
            signUpBirthdate.setVisible(true);
            signUpNum.setVisible(true);
        } else {
            signUpCompTitle.setVisible(true);
            signUpCeo.setVisible(true);
            signUpLegal.setVisible(true);
        }
    }
}
